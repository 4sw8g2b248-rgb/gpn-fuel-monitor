from app.config import Config
from app.scraper import parse_network_payloads


def test_simple_payload():
    cfg = Config()
    payload = {
        "stations": [
            {
                "id": 62,
                "name": "АЗС №62",
                "city": "Каменск-Уральский",
                "address": "Ленина, 27",
                "latitude": 56.414459,
                "longitude": 61.91459,
                "fuels": [
                    {"name": "95", "price": 68.01, "status": "В пути"},
                    {"name": "92", "price": 64.16, "status": "Отсутствует"},
                ],
            }
        ]
    }
    rows = parse_network_payloads(cfg, [("https://example/api", payload)])
    assert rows
    assert any(r.status == "ON_WAY" for r in rows)


def test_three_target_fuels():
    cfg = Config()
    payload = {
        "stations": [{
            "id": 62,
            "name": "АЗС №62",
            "city": "Каменск-Уральский",
            "address": "Ленина, 27",
            "latitude": 56.414459,
            "longitude": 61.91459,
            "fuels": [
                {"name": "АИ-95", "status": "В пути"},
                {"name": "G-95", "status": "В пути"},
                {"name": "G-100", "status": "В пути"},
                {"name": "92", "status": "В пути"},
            ],
        }]
    }
    rows = parse_network_payloads(cfg, [("https://example/api", payload)])
    names = {r.fuel_name for r in rows if r.status == "ON_WAY"}
    assert "АИ-95" in names
    assert "G-95" in names
    assert "G-100" in names
    assert "92" not in names
