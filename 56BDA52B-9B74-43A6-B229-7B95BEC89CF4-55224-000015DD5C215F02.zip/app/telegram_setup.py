from __future__ import annotations

import asyncio
import os
import sys
import httpx
from dotenv import load_dotenv

load_dotenv()


async def main() -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        print("Ошибка: заполните TELEGRAM_BOT_TOKEN в .env")
        sys.exit(1)

    url = f"https://api.telegram.org/bot{token}/getUpdates"
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(url)
        r.raise_for_status()
        data = r.json()

    results = data.get("result", [])
    private = []
    for item in results:
        msg = item.get("message") or item.get("edited_message") or {}
        chat = msg.get("chat") or {}
        if chat.get("type") == "private" and chat.get("id"):
            private.append((chat.get("id"), chat.get("username"), chat.get("first_name")))

    if not private:
        print("Не найден личный чат. Откройте своего бота в Telegram, нажмите Start или отправьте /start, затем повторите команду.")
        return

    print("Найденные личные чаты:")
    seen = set()
    for chat_id, username, first_name in reversed(private):
        if chat_id in seen:
            continue
        seen.add(chat_id)
        print(f"TELEGRAM_CHAT_ID={chat_id}   @{username or '-'}   {first_name or ''}")


if __name__ == "__main__":
    asyncio.run(main())
