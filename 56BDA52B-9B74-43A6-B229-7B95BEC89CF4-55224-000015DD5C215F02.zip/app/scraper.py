from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from playwright.async_api import async_playwright, Page, Response

from .config import Config
from .models import FuelObservation

log = logging.getLogger(__name__)

ADDRESS_KEYS = ("address", "addr", "fulladdress", "addressline", "street", "locationaddress")
CITY_KEYS = ("city", "town", "locality", "settlement")
ID_KEYS = ("id", "stationid", "azsid", "gasstationid", "objectid", "uuid")
NAME_KEYS = ("name", "title", "stationname", "azsname", "caption")
LAT_KEYS = ("lat", "latitude", "y")
LON_KEYS = ("lon", "lng", "long", "longitude", "x")
PRICE_KEYS = ("price", "cost", "value")

ON_WAY_WORDS = (
    "в пути", "in transit", "in_transit", "in-transit", "on way", "on_way", "on-way",
    "delivery", "delivering", "tanker", "truck on way", "route",
)
AVAILABLE_WORDS = ("в наличии", "available", "in stock", "instock")
UNAVAILABLE_WORDS = ("отсутствует", "unavailable", "out of stock", "not available", "absent")


def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "").strip().lower().replace("ё", "е"))


def _keynorm(s: Any) -> str:
    return re.sub(r"[^a-zа-я0-9]", "", _norm(s))


def _walk_dicts(obj: Any) -> Iterable[dict[str, Any]]:
    if isinstance(obj, dict):
        yield obj
        for v in obj.values():
            yield from _walk_dicts(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _walk_dicts(v)


def _all_text(obj: Any, limit: int = 20000) -> str:
    chunks: list[str] = []
    def rec(v: Any) -> None:
        if sum(len(x) for x in chunks) >= limit:
            return
        if isinstance(v, dict):
            for k, val in v.items():
                chunks.append(str(k))
                rec(val)
        elif isinstance(v, list):
            for x in v:
                rec(x)
        elif isinstance(v, (str, int, float, bool)):
            chunks.append(str(v))
    rec(obj)
    return _norm(" ".join(chunks))


def _find_scalar(d: dict[str, Any], keys: tuple[str, ...]) -> Any | None:
    normalized = {_keynorm(k): v for k, v in d.items()}
    for target in keys:
        t = _keynorm(target)
        if t in normalized and isinstance(normalized[t], (str, int, float)):
            return normalized[t]
    return None


def _find_deep_scalar(d: dict[str, Any], keys: tuple[str, ...]) -> Any | None:
    direct = _find_scalar(d, keys)
    if direct is not None:
        return direct
    for child in _walk_dicts(d):
        if child is d:
            continue
        val = _find_scalar(child, keys)
        if val is not None:
            return val
    return None


def _float_or_none(v: Any) -> float | None:
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return None


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2 * r * math.asin(math.sqrt(a))


def _matches_city_or_radius(cfg: Config, city: str, address: str, lat: float | None, lon: float | None) -> bool:
    target = _norm(cfg.target_city)
    place = _norm(f"{city} {address}")
    if target and target in place:
        return True
    # Нормализация дефисов/вариантов написания
    if target.replace("-", " ") in place.replace("-", " "):
        return True
    if lat is not None and lon is not None:
        return haversine_km(cfg.target_lat, cfg.target_lon, lat, lon) <= cfg.radius_km
    return False


def _fuel_matches(text: str, aliases: tuple[str, ...]) -> bool:
    n = _keynorm(text)
    alias_norms = {_keynorm(a) for a in aliases}
    # Не считаем G-95 обычным 95, если G-95 явно не указан в aliases.
    wants_g95 = any(a in {"g95", "gai95"} or a.startswith("g95") for a in alias_norms)
    if ("g95" in n or "gai95" in n) and not wants_g95:
        return False
    return any(a and (a == n or a in n) for a in alias_norms)


def _status_from_dict(d: dict[str, Any]) -> str:
    text = _all_text(d, limit=5000)
    if any(w in text for w in ON_WAY_WORDS):
        return "ON_WAY"
    if any(w in text for w in AVAILABLE_WORDS):
        return "AVAILABLE"
    if any(w in text for w in UNAVAILABLE_WORDS):
        return "UNAVAILABLE"

    # Boolean/enum эвристики для статуса доставки.
    for k, v in d.items():
        nk = _keynorm(k)
        nv = _norm(v)
        if any(x in nk for x in ("transit", "onway", "delivery", "tanker", "truck", "route")):
            if v is True or nv in {"true", "1", "yes", "active", "onway", "intransit"}:
                return "ON_WAY"
    return "UNKNOWN"


def _extract_price(d: dict[str, Any]) -> str | None:
    for child in _walk_dicts(d):
        val = _find_scalar(child, PRICE_KEYS)
        if val is not None:
            sval = str(val).strip()
            if re.search(r"\d", sval):
                return sval
    return None


def _fuel_atoms(station: dict[str, Any], aliases: tuple[str, ...]) -> list[tuple[str, str, str | None]]:
    out: list[tuple[str, str, str | None]] = []
    seen: set[str] = set()
    for d in _walk_dicts(station):
        txt = _all_text(d, limit=5000)
        if not _fuel_matches(txt, aliases):
            continue
        status = _status_from_dict(d)
        # Если огромный station dict содержит несколько топлив, не используем его как atom,
        # когда ниже есть более компактные словари. Предпочитаем dict <= 30 полей.
        if len(d) > 30 and status == "UNKNOWN":
            continue
        # Ищем наиболее похожее имя топлива.
        fuel_name = None
        for val in d.values():
            if isinstance(val, (str, int, float)) and _fuel_matches(str(val), aliases):
                fuel_name = str(val)
                break
        fuel_name = fuel_name or aliases[0]
        signature = f"{_keynorm(fuel_name)}|{status}|{_extract_price(d)}"
        if signature in seen:
            continue
        seen.add(signature)
        out.append((fuel_name, status, _extract_price(d)))
    return out


def parse_network_payloads(cfg: Config, payloads: list[tuple[str, Any]]) -> list[FuelObservation]:
    observations: list[FuelObservation] = []
    seen_obs: set[tuple[str, str, str]] = set()
    now = datetime.now(timezone.utc)

    for source_url, payload in payloads:
        for d in _walk_dicts(payload):
            # Станция должна иметь адрес/город/координаты, иначе слишком велик риск ложного совпадения.
            address = str(_find_deep_scalar(d, ADDRESS_KEYS) or "").strip()
            city = str(_find_deep_scalar(d, CITY_KEYS) or "").strip()
            lat = _float_or_none(_find_deep_scalar(d, LAT_KEYS))
            lon = _float_or_none(_find_deep_scalar(d, LON_KEYS))
            if not (address or city or (lat is not None and lon is not None)):
                continue
            if not _matches_city_or_radius(cfg, city, address, lat, lon):
                continue

            atoms = _fuel_atoms(d, cfg.fuel_aliases)
            if not atoms:
                continue

            sid = str(_find_deep_scalar(d, ID_KEYS) or "").strip()
            name = str(_find_deep_scalar(d, NAME_KEYS) or "").strip()
            if not name:
                name = "АЗС"
            base = sid or f"{name}|{address}|{lat}|{lon}"
            station_key = hashlib.sha1(base.encode("utf-8", errors="ignore")).hexdigest()[:20]

            for fuel_name, status, price in atoms:
                # UNKNOWN тоже сохраняем: он полезен для диагностики/переходов.
                key = (station_key, _keynorm(fuel_name), status)
                if key in seen_obs:
                    continue
                seen_obs.add(key)
                observations.append(FuelObservation(
                    station_key=station_key,
                    station_name=name,
                    address=address,
                    city=city or cfg.target_city,
                    lat=lat,
                    lon=lon,
                    fuel_name=fuel_name,
                    status=status,
                    price=price,
                    source_url=cfg.page_url,
                    seen_at=now,
                ))

    # На одну станцию/топливо выбираем наиболее информативный статус.
    priority = {"ON_WAY": 4, "AVAILABLE": 3, "UNAVAILABLE": 2, "UNKNOWN": 1}
    merged: dict[tuple[str, str], FuelObservation] = {}
    for obs in observations:
        k = (obs.station_key, _keynorm(obs.fuel_name))
        if k not in merged or priority.get(obs.status, 0) > priority.get(merged[k].status, 0):
            merged[k] = obs
    return list(merged.values())


async def _dismiss_popups(page: Page) -> None:
    candidates = [
        "button:has-text('Принять')", "button:has-text('Согласен')", "button:has-text('Понятно')",
        "button:has-text('Хорошо')", "button:has-text('Закрыть')", "text=Принять все",
    ]
    for selector in candidates:
        try:
            loc = page.locator(selector).first
            if await loc.is_visible(timeout=600):
                await loc.click(timeout=1000)
                await page.wait_for_timeout(300)
        except Exception:
            pass


async def _try_city_search(page: Page, city: str) -> None:
    # Сайт меняется, поэтому используем несколько безопасных эвристик.
    selectors = [
        "input[placeholder*='город' i]",
        "input[placeholder*='адрес' i]",
        "input[placeholder*='поиск' i]",
        "input[type='search']",
    ]
    for selector in selectors:
        try:
            loc = page.locator(selector).first
            if await loc.is_visible(timeout=800):
                await loc.fill(city)
                await page.wait_for_timeout(1000)
                # Если есть подсказка с городом — выбираем её.
                suggestion = page.get_by_text(city, exact=False).first
                try:
                    if await suggestion.is_visible(timeout=1000):
                        await suggestion.click(timeout=1500)
                    else:
                        await loc.press("Enter")
                except Exception:
                    await loc.press("Enter")
                await page.wait_for_timeout(2500)
                return
        except Exception:
            continue


async def _dom_fallback(cfg: Config, page: Page) -> list[FuelObservation]:
    try:
        text = await page.locator("body").inner_text(timeout=5000)
    except Exception:
        return []
    ntext = _norm(text)
    if not _fuel_matches(ntext, cfg.fuel_aliases) or "в пути" not in ntext:
        return []

    # Fallback используется только когда на странице явно есть целевой город + 95 + "В пути".
    if _norm(cfg.target_city).replace("-", " ") not in ntext.replace("-", " "):
        return []

    station_match = re.search(r"АЗС\s*№?\s*([\w-]+)", text, flags=re.I)
    addr_match = re.search(r"(?:ул\.?\s*)?([А-ЯЁA-Z][^\n]{2,80},\s*\d+[А-ЯA-Zа-яa-z/-]*)", text)
    station_name = f"АЗС №{station_match.group(1)}" if station_match else "АЗС"
    address = addr_match.group(0).strip() if addr_match else ""
    base = f"dom|{station_name}|{address}|{cfg.target_city}"
    key = hashlib.sha1(base.encode("utf-8")).hexdigest()[:20]
    return [FuelObservation(
        station_key=key,
        station_name=station_name,
        address=address,
        city=cfg.target_city,
        lat=None,
        lon=None,
        fuel_name=cfg.fuel_aliases[0],
        status="ON_WAY",
        price=None,
        source_url=cfg.page_url,
        seen_at=datetime.now(timezone.utc),
    )]


async def scrape(cfg: Config) -> list[FuelObservation]:
    payloads: list[tuple[str, Any]] = []
    pending: set[asyncio.Task] = set()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=cfg.headless)
        context = await browser.new_context(
            locale="ru-RU",
            timezone_id="Asia/Yekaterinburg",
            geolocation={"latitude": cfg.target_lat, "longitude": cfg.target_lon},
            permissions=["geolocation"],
            viewport={"width": 1440, "height": 1000},
        )
        page = await context.new_page()
        page.set_default_timeout(cfg.page_timeout_ms)

        async def consume_response(response: Response) -> None:
            try:
                ctype = (response.headers.get("content-type") or "").lower()
                if "json" not in ctype:
                    return
                data = await response.json()
                payloads.append((response.url, data))
            except Exception:
                return

        def on_response(response: Response) -> None:
            task = asyncio.create_task(consume_response(response))
            pending.add(task)
            task.add_done_callback(pending.discard)

        page.on("response", on_response)

        try:
            log.info("Открываю карту: %s", cfg.page_url)
            await page.goto(cfg.page_url, wait_until="domcontentloaded", timeout=cfg.page_timeout_ms)
            await _dismiss_popups(page)
            await _try_city_search(page, cfg.target_city)
            await page.wait_for_timeout(cfg.post_load_wait_seconds * 1000)
            if pending:
                await asyncio.gather(*list(pending), return_exceptions=True)

            obs = parse_network_payloads(cfg, payloads)
            if not obs:
                log.warning("Из сетевых JSON не удалось получить АЗС. Пробую DOM fallback.")
                obs = await _dom_fallback(cfg, page)

            if cfg.debug_dump_network:
                debug_dir = Path("/data/debug")
                debug_dir.mkdir(parents=True, exist_ok=True)
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                safe_payloads = [{"url": u, "data": d} for u, d in payloads]
                (debug_dir / f"network_{stamp}.json").write_text(
                    json.dumps(safe_payloads, ensure_ascii=False, indent=2), encoding="utf-8"
                )
                (debug_dir / f"page_{stamp}.html").write_text(await page.content(), encoding="utf-8")
                await page.screenshot(path=str(debug_dir / f"page_{stamp}.png"), full_page=True)

            log.info("Найдено наблюдений по АИ-95: %d", len(obs))
            return obs
        finally:
            await context.close()
            await browser.close()
