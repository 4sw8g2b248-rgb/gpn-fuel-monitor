from __future__ import annotations

import sqlite3
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any

from .models import FuelObservation


SCHEMA = """
CREATE TABLE IF NOT EXISTS station_state (
    station_key TEXT NOT NULL,
    fuel_name TEXT NOT NULL,
    station_name TEXT,
    address TEXT,
    city TEXT,
    last_status TEXT,
    last_price TEXT,
    last_seen_at TEXT,
    PRIMARY KEY (station_key, fuel_name)
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    station_key TEXT NOT NULL,
    fuel_name TEXT NOT NULL,
    old_status TEXT,
    new_status TEXT NOT NULL,
    station_name TEXT,
    address TEXT,
    city TEXT,
    price TEXT,
    detected_at TEXT NOT NULL,
    notified INTEGER NOT NULL DEFAULT 0
);
"""


class StateStore:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def get_previous(self, station_key: str, fuel_name: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM station_state WHERE station_key=? AND fuel_name=?",
            (station_key, fuel_name),
        ).fetchone()
        return dict(row) if row else None

    def upsert(self, obs: FuelObservation) -> None:
        self.conn.execute(
            """
            INSERT INTO station_state(
                station_key, fuel_name, station_name, address, city,
                last_status, last_price, last_seen_at
            ) VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(station_key, fuel_name) DO UPDATE SET
                station_name=excluded.station_name,
                address=excluded.address,
                city=excluded.city,
                last_status=excluded.last_status,
                last_price=excluded.last_price,
                last_seen_at=excluded.last_seen_at
            """,
            (
                obs.station_key, obs.fuel_name, obs.station_name, obs.address, obs.city,
                obs.status, obs.price, obs.seen_at.isoformat()
            ),
        )
        self.conn.commit()

    def add_event(self, obs: FuelObservation, old_status: str | None) -> int:
        cur = self.conn.execute(
            """
            INSERT INTO events(
                station_key, fuel_name, old_status, new_status, station_name,
                address, city, price, detected_at, notified
            ) VALUES(?,?,?,?,?,?,?,?,?,0)
            """,
            (
                obs.station_key, obs.fuel_name, old_status, obs.status,
                obs.station_name, obs.address, obs.city, obs.price, obs.seen_at.isoformat()
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def mark_notified(self, event_id: int) -> None:
        self.conn.execute("UPDATE events SET notified=1 WHERE id=?", (event_id,))
        self.conn.commit()
