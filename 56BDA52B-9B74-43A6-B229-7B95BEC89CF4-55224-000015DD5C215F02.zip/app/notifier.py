from __future__ import annotations

import logging
from html import escape

import httpx

from .config import Config
from .models import FuelObservation

log = logging.getLogger(__name__)


def _status_label(status: str) -> str:
    return {
        "ON_WAY": "В пути",
        "AVAILABLE": "В наличии",
        "UNAVAILABLE": "Отсутствует",
        "UNKNOWN": "Неизвестно",
    }.get(status, status)


def build_message(obs: FuelObservation) -> str:
    status = _status_label(obs.status)
    price = f"\n💳 Цена: {escape(obs.price)}" if obs.price else ""
    station = escape(obs.station_name or "не указано")
    address = escape(obs.address or "не указан")
    city = escape(obs.city)
    fuel = escape(obs.fuel_name)
    seen = obs.seen_at.astimezone().strftime("%d.%m.%Y %H:%M:%S")

    return (
        f"🚚 <b>{fuel} — {escape(status.upper())}</b>\n\n"
        f"📍 <b>Город:</b> {city}\n"
        f"⛽ <b>АЗС:</b> {station}\n"
        f"🏠 <b>Адрес:</b> {address}\n"
        f"🛢 <b>Топливо:</b> {fuel}\n"
        f"🕒 <b>Обнаружено:</b> {seen}"
        f"{price}"
    )


async def send_telegram(cfg: Config, obs: FuelObservation) -> bool:
    if not cfg.telegram_bot_token or not cfg.telegram_chat_id:
        log.warning("Telegram пропущен: не заполнен TELEGRAM_BOT_TOKEN или TELEGRAM_CHAT_ID")
        return False

    url = f"https://api.telegram.org/bot{cfg.telegram_bot_token}/sendMessage"
    payload = {
        "chat_id": cfg.telegram_chat_id,
        "text": build_message(obs),
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
        "reply_markup": {
            "inline_keyboard": [[
                {"text": "Открыть карту Газпромнефть", "url": obs.source_url}
            ]]
        },
    }

    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(url, json=payload)
        r.raise_for_status()

    log.info("Telegram-уведомление отправлено в chat_id=%s", cfg.telegram_chat_id)
    return True
