from __future__ import annotations

import argparse
import asyncio
import logging
import sys
import time
from logging.handlers import RotatingFileHandler

from .config import Config
from .notifier import send_telegram
from .scraper import scrape
from .state import StateStore


def setup_logging(cfg: Config) -> None:
    cfg.log_file.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.setLevel(getattr(logging, cfg.log_level, logging.INFO))
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    root.addHandler(sh)

    fh = RotatingFileHandler(cfg.log_file, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(fh)


async def process_once(cfg: Config, store: StateStore) -> None:
    log = logging.getLogger(__name__)
    observations = await scrape(cfg)
    if not observations:
        log.warning("Нет данных по целевым видам топлива (АИ-95 / G-95 / G-100). Проверьте /logs/monitor.log; для диагностики включите DEBUG_DUMP_NETWORK=true.")
        return

    for obs in observations:
        prev = store.get_previous(obs.station_key, obs.fuel_name)
        old_status = prev["last_status"] if prev else None
        changed = old_status != obs.status

        should_alert_on_way = obs.is_on_way and (
            (prev is None and cfg.alert_on_first_seen) or (prev is not None and old_status != "ON_WAY")
        )
        should_alert_available = cfg.alert_when_available and obs.is_available and prev is not None and old_status != "AVAILABLE"

        if changed:
            log.info(
                "Изменение: %s | %s | %s -> %s | %s",
                obs.station_name, obs.address, old_status, obs.status, obs.fuel_name
            )
            event_id = store.add_event(obs, old_status)
            # В GitHub Actions состояние хранится в репозитории.
            # Не переписываем БД при неизменном статусе, чтобы не создавать
            # бессмысленный commit каждые 5 минут.
            store.upsert(obs)
        else:
            event_id = None

        if should_alert_on_way or should_alert_available:
            success = False
            try:
                sent_tg = await send_telegram(cfg, obs)
                success = success or sent_tg
            except Exception:
                log.exception("Ошибка Telegram")
            if event_id is not None and success:
                store.mark_notified(event_id)


async def main_async(once: bool) -> None:
    cfg = Config()
    setup_logging(cfg)
    log = logging.getLogger(__name__)
    for warning in cfg.validate_runtime():
        log.warning(warning)

    store = StateStore(cfg.state_db)
    if once:
        await process_once(cfg, store)
        return

    log.info("Монитор запущен. Интервал: %s сек.", cfg.check_interval_seconds)
    while True:
        started = time.monotonic()
        try:
            await process_once(cfg, store)
        except Exception:
            log.exception("Ошибка цикла мониторинга")
        elapsed = time.monotonic() - started
        await asyncio.sleep(max(5, cfg.check_interval_seconds - elapsed))


def cli() -> None:
    parser = argparse.ArgumentParser(description="Монитор АИ-95 / G-95 / G-100 со статусом 'В пути' на карте Газпромнефть")
    parser.add_argument("--once", action="store_true", help="Одна проверка и выход")
    args = parser.parse_args()
    asyncio.run(main_async(args.once))


if __name__ == "__main__":
    cli()
