from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class FuelObservation:
    station_key: str
    station_name: str
    address: str
    city: str
    lat: float | None
    lon: float | None
    fuel_name: str
    status: str
    price: str | None
    source_url: str
    seen_at: datetime

    @property
    def is_on_way(self) -> bool:
        return self.status == "ON_WAY"

    @property
    def is_available(self) -> bool:
        return self.status == "AVAILABLE"
