from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on", "да"}


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class Config:
    page_url: str = os.getenv("PAGE_URL", "https://gpnbonus.ru/fuel/refuel-map")
    target_city: str = os.getenv("TARGET_CITY", "Каменск-Уральский")
    target_lat: float = _float("TARGET_LAT", 56.4149)
    target_lon: float = _float("TARGET_LON", 61.9187)
    radius_km: float = _float("RADIUS_KM", 25.0)
    check_interval_seconds: int = _int("CHECK_INTERVAL_SECONDS", 300)
    fuel_aliases: tuple[str, ...] = tuple(
        x.strip() for x in os.getenv("FUEL_ALIASES", "95,АИ-95,AI-95,G-95,G95,G-100,G100").split(",") if x.strip()
    )
    alert_on_first_seen: bool = _bool("ALERT_ON_FIRST_SEEN", True)
    alert_when_available: bool = _bool("ALERT_WHEN_AVAILABLE", False)

    headless: bool = _bool("HEADLESS", True)
    page_timeout_ms: int = _int("PAGE_TIMEOUT_MS", 60000)
    post_load_wait_seconds: int = _int("POST_LOAD_WAIT_SECONDS", 8)
    debug_dump_network: bool = _bool("DEBUG_DUMP_NETWORK", False)

    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "").strip()

    state_db: Path = Path(os.getenv("STATE_DB", "/data/state.sqlite3"))
    log_file: Path = Path(os.getenv("LOG_FILE", "/logs/monitor.log"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO").upper()

    def validate_runtime(self) -> list[str]:
        warnings: list[str] = []
        if not self.telegram_bot_token:
            warnings.append("Не заполнен TELEGRAM_BOT_TOKEN.")
        if not self.telegram_chat_id:
            warnings.append("Не заполнен TELEGRAM_CHAT_ID.")
        return warnings
