from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from .config import Config
from .models import FuelObservation
from .notifier import send_telegram


async def main() -> None:
    cfg = Config()
    obs = FuelObservation(
        station_key="test",
        station_name="ТЕСТОВАЯ АЗС",
        address="Каменск-Уральский",
        city=cfg.target_city,
        lat=cfg.target_lat,
        lon=cfg.target_lon,
        fuel_name="АИ-95",
        status="ON_WAY",
        price=None,
        source_url=cfg.page_url,
        seen_at=datetime.now(timezone.utc),
    )
    print("Отправляю тестовое Telegram-уведомление...")
    try:
        print("Telegram:", await send_telegram(cfg, obs))
    except Exception as e:
        print("Telegram ERROR:", repr(e))


if __name__ == "__main__":
    asyncio.run(main())
